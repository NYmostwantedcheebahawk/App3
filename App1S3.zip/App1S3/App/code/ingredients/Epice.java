package ingredients;

public class Epice extends Ingredient {
    public Epice(String s) {
        setStateIngredient(s);
        setTypeIngredient(TypeIngredient.EPICE);
    }
}