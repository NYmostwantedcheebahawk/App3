package ingredients;

public class Fruit extends Ingredient{
    public Fruit(String s) {
        setStateIngredient(s);
        setTypeIngredient(TypeIngredient.FRUIT);
    }
}
