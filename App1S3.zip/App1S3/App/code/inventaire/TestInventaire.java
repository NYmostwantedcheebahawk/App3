package inventaire;

public class TestInventaire {
}
